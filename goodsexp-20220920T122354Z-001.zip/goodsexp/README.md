# courier_managment_system
Courier Managment System in PHP

====================================================================================

Language Used: PHP, HTML, CSS, Bootstrap, JavaScript, jQuery, AJAX, JSON
Database: MySQL

=====================================================================================
Project Description:

Courier Management System which supports the high accessibility of courier
service to the customers. The system is being used for day to day activity such as
booking a courier, maintain hub details, maintain staff details and many other
things. It has divided in four modules: Admin, Branch, Staff and Users.

============================================================================

Import "courier.sql" for Database.
Refer "PHP Logis Id Password.pdf" Admin password.
