<?php
	$dt = new DateTime();
    echo $dt->format('Y-m-d H:i:s');
?>